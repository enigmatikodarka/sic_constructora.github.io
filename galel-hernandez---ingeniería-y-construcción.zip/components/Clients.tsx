import React from 'react';
import Section from './ui/Section';
import { CLIENTS } from '../constants';

const Clients: React.FC = () => {
  return (
    <Section 
      id="clients" 
      title="Nuestros Clientes" 
      subtitle="Entidades que han confiado en nuestra solidez y experiencia"
      className="bg-black"
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {CLIENTS.map((client) => (
          <div 
            key={client.id}
            className="h-32 bg-dark-surface border border-white/5 rounded-lg flex items-center justify-center p-4 hover:border-gold hover:shadow-[0_0_10px_rgba(212,175,55,0.2)] transition-all group"
          >
            {/* Placeholder for Logo - In a real app, <img src={client.logoUrl} /> */}
            <div className="text-center">
               <span className="text-gray-500 font-bold text-lg group-hover:text-white transition-colors duration-300">
                 {client.name}
               </span>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default Clients;