import React from 'react';
import Section from './ui/Section';
import { MACHINERY } from '../constants';
import { motion } from 'framer-motion';

const Machinery: React.FC = () => {
  return (
    <Section 
      id="machinery" 
      title="Nuestra Maquinaria" 
      subtitle="Contamos con flota propia para garantizar tiempos y calidad"
      className="bg-black"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {MACHINERY.map((item, index) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="group relative bg-dark-surface border border-white/5 rounded-xl p-6 hover:border-gold transition-all duration-300"
          >
            <div className="absolute top-4 right-4 text-3xl font-bold text-white/5 group-hover:text-gold/10 transition-colors">
              0{index + 1}
            </div>
            
            <div className="w-14 h-14 bg-gold/10 rounded-lg flex items-center justify-center text-gold mb-6 group-hover:bg-gold group-hover:text-black transition-colors duration-300">
              <item.icon size={28} strokeWidth={1.5} />
            </div>

            <div className="flex justify-between items-end mb-2">
                <h3 className="text-lg font-bold text-white group-hover:text-gold transition-colors">{item.name}</h3>
                <span className="text-xs font-bold bg-white/10 px-2 py-1 rounded text-gold">{item.count} Unid.</span>
            </div>
            
            <p className="text-gray-400 text-sm leading-relaxed">
              {item.description}
            </p>
          </motion.div>
        ))}
      </div>
      
      {/* Heavy Machinery Banner Image */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="mt-16 relative rounded-2xl overflow-hidden h-64 md:h-80 border border-white/10"
      >
        <img 
          src="https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80" 
          alt="Maquinaria Pesada en Obra" 
          className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-700"
        />
        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <div className="text-center px-6">
                <h3 className="text-2xl md:text-3xl font-display font-bold text-white mb-2">Capacidad Operativa Inmediata</h3>
                <p className="text-gray-300">Disponibilidad de equipo pesado para iniciar proyectos sin demoras por alquiler.</p>
            </div>
        </div>
      </motion.div>
    </Section>
  );
};

export default Machinery;