import React from 'react';
import Section from './ui/Section';
import { SERVICES } from '../constants';
import { motion } from 'framer-motion';

const Services: React.FC = () => {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <Section 
      id="services" 
      title="Nuestros Servicios" 
      subtitle="Soluciones integrales diseñadas para cada tipo de necesidad de infraestructura"
      className="bg-black"
    >
      <motion.div 
        variants={container}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {SERVICES.map((service) => (
          <motion.div 
            key={service.id} 
            variants={item}
            className="group p-8 bg-dark-surface rounded-xl border border-white/5 hover:border-gold transition-all duration-300 hover:bg-dark-card"
          >
            <div className="w-14 h-14 bg-gold rounded-full flex items-center justify-center mb-6 text-black group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(212,175,55,0.4)]">
              <service.icon size={28} />
            </div>
            <h3 className="text-xl font-bold text-white mb-3 group-hover:text-gold transition-colors">{service.title}</h3>
            <p className="text-gray-400 leading-relaxed text-sm">
              {service.description}
            </p>
          </motion.div>
        ))}
      </motion.div>
    </Section>
  );
};

export default Services;