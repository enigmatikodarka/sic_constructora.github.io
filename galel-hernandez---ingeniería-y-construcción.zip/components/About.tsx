import React from 'react';
import Section from './ui/Section';
import { Target, Eye } from 'lucide-react';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  return (
    <>
      <Section id="about" title="Sobre Nosotros" subtitle="Comprometidos con la excelencia y la seguridad en cada obra" pattern="dots">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          
          {/* Text Content */}
          <div className="lg:w-1/2">
            <h3 className="text-2xl font-bold text-white mb-4">¿Quiénes Somos?</h3>
            <div className="space-y-4 text-gray-400 leading-relaxed">
              <p>
                <strong className="text-gold">Servicios de Ingeniería y Construcción Galel Hernandez Romero S.de R.L.de C.V</strong> es una empresa líder en el sector de la construcción e ingeniería, con amplia experiencia en el desarrollo de proyectos civiles, industriales y comerciales.
              </p>
              <p>
                Fundada en 2006, nos hemos destacado por ofrecer soluciones innovadoras, eficientes y sostenibles, cumpliendo con los más altos estándares de calidad y seguridad.
              </p>
              <p>
                Nuestra capacidad operativa incluye maquinaria propia y un equipo técnico especializado, lo que nos permite garantizar resultados excepcionales en tiempos óptimos.
              </p>
            </div>
            
            <div className="mt-8 grid grid-cols-2 gap-4">
              <div className="bg-dark-surface p-4 border border-white/10 rounded-lg text-center">
                <span className="block text-3xl font-bold text-gold mb-1">19+</span>
                <span className="text-sm text-gray-500">Años de Experiencia</span>
              </div>
              <div className="bg-dark-surface p-4 border border-white/10 rounded-lg text-center">
                <span className="block text-3xl font-bold text-gold mb-1">150+</span>
                <span className="text-sm text-gray-500">Proyectos Completados</span>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="lg:w-1/2 relative">
            <div className="absolute top-4 left-4 w-full h-full border-2 border-gold/30 rounded-lg transform translate-x-4 translate-y-4 -z-10"></div>
            <img 
              src="https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
              alt="Ingenieros en obra" 
              className="rounded-lg shadow-2xl grayscale hover:grayscale-0 transition-all duration-500"
            />
          </div>
        </div>
      </Section>

      {/* Vision & Mission Cards (Embedded nearby) */}
      <section className="py-16 bg-dark-surface relative border-t border-b border-white/5">
        <div className="container mx-auto px-6">
           <div className="grid md:grid-cols-2 gap-8">
             {/* Vision */}
             <motion.div 
               whileHover={{ y: -5 }}
               className="bg-dark-bg p-8 rounded-xl border border-white/10 hover:border-gold/50 transition-colors group"
             >
                <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 group-hover:bg-gold/20 transition-colors">
                  <Eye className="text-gold" size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-4">Nuestra Visión</h3>
                <p className="text-gray-400">
                  Ser reconocidos como líderes en la industria de la construcción e ingeniería, destacándonos por nuestra excelencia, innovación y compromiso con el desarrollo sostenible. Aspiramos a expandir nuestra presencia a nivel nacional e internacional.
                </p>
             </motion.div>

             {/* Mission */}
             <motion.div 
               whileHover={{ y: -5 }}
               className="bg-dark-bg p-8 rounded-xl border border-white/10 hover:border-gold/50 transition-colors group"
             >
                <div className="w-12 h-12 bg-gold/10 rounded-full flex items-center justify-center mb-6 group-hover:bg-gold/20 transition-colors">
                  <Target className="text-gold" size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-4">Nuestra Misión</h3>
                <p className="text-gray-400">
                  Proporcionar soluciones integrales de ingeniería y construcción que superen las expectativas de nuestros clientes. Nos comprometemos a trabajar con integridad, responsabilidad y pasión, creando valor para nuestros clientes.
                </p>
             </motion.div>
           </div>
        </div>
      </section>
    </>
  );
};

export default About;