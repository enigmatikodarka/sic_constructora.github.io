import React from 'react';
import { motion } from 'framer-motion';

interface SectionProps {
  id: string;
  title?: string;
  subtitle?: string;
  className?: string;
  children: React.ReactNode;
  pattern?: 'dots' | 'grid' | 'none';
}

const Section: React.FC<SectionProps> = ({ 
  id, 
  title, 
  subtitle, 
  className = "", 
  children,
  pattern = 'none' 
}) => {
  
  let bgPattern = "";
  if (pattern === 'dots') {
    bgPattern = `background-image: radial-gradient(#333 1px, transparent 1px); background-size: 20px 20px;`;
  } else if (pattern === 'grid') {
    bgPattern = `background-image: linear-gradient(#222 1px, transparent 1px), linear-gradient(90deg, #222 1px, transparent 1px); background-size: 40px 40px;`;
  }

  return (
    <section 
      id={id} 
      className={`py-20 md:py-28 relative overflow-hidden ${className}`}
      style={pattern !== 'none' ? { backgroundImage: bgPattern } : {}}
    >
      <div className="container mx-auto px-6 relative z-10">
        {(title || subtitle) && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            {title && (
              <h2 className="text-3xl md:text-4xl font-display font-bold mb-4 relative inline-block">
                {title}
                <span className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-gold"></span>
              </h2>
            )}
            {subtitle && (
              <p className="text-gray-400 mt-6 max-w-2xl mx-auto text-lg">
                {subtitle}
              </p>
            )}
          </motion.div>
        )}
        {children}
      </div>
    </section>
  );
};

export default Section;