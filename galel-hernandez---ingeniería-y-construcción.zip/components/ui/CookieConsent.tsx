import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cookie } from 'lucide-react';

const CookieConsent: React.FC = () => {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) {
      const timer = setTimeout(() => setShow(true), 3000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookie-consent', 'true');
    setShow(false);
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 50 }}
          className="fixed bottom-4 left-4 z-50 max-w-sm bg-dark-surface border border-gold/20 shadow-2xl p-6 rounded-lg"
        >
          <div className="flex items-start gap-4">
            <div className="text-gold mt-1">
              <Cookie size={24} />
            </div>
            <div>
              <h4 className="text-white font-bold mb-2">Uso de Cookies</h4>
              <p className="text-sm text-gray-400 mb-4 leading-relaxed">
                Utilizamos cookies para mejorar su experiencia de navegación y analizar nuestro tráfico. Al continuar, acepta nuestro uso de cookies.
              </p>
              <div className="flex gap-3">
                <button 
                  onClick={handleAccept}
                  className="bg-gold hover:bg-gold-dark text-black text-xs font-bold py-2 px-4 rounded transition-colors"
                >
                  Aceptar
                </button>
                <button 
                  onClick={() => setShow(false)}
                  className="text-gray-400 hover:text-white text-xs font-medium py-2 px-2"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieConsent;