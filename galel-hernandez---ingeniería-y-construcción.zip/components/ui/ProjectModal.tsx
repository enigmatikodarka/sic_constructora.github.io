import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Calendar, MapPin, User, ArrowRight } from 'lucide-react';
import { Project } from '../../types';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/90 backdrop-blur-sm cursor-pointer"
        />

        {/* Modal Content */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative bg-dark-surface w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-2xl border border-white/10 shadow-2xl flex flex-col md:flex-row overflow-hidden"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 p-2 bg-black/50 text-white rounded-full hover:bg-gold hover:text-black transition-colors"
          >
            <X size={20} />
          </button>

          {/* Image Side */}
          <div className="md:w-1/2 h-64 md:h-auto relative">
            <img 
              src={project.image} 
              alt={project.title} 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-surface via-transparent to-transparent md:bg-gradient-to-r"></div>
          </div>

          {/* Info Side */}
          <div className="md:w-1/2 p-8 flex flex-col">
            <div className="mb-6">
              <span className="inline-block py-1 px-3 border border-gold/30 rounded-full text-xs font-bold text-gold uppercase tracking-wider mb-3">
                {project.category}
              </span>
              <h2 className="text-3xl font-display font-bold text-white mb-4">{project.title}</h2>
              <p className="text-gray-300 leading-relaxed mb-6">
                {project.details || project.description}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4 mt-auto">
              <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg border border-white/5">
                <div className="text-gold"><User size={20} /></div>
                <div>
                  <p className="text-xs text-gray-500 uppercase">Cliente</p>
                  <p className="text-white font-medium">{project.client || "Confidencial"}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg border border-white/5">
                <div className="text-gold"><MapPin size={20} /></div>
                <div>
                  <p className="text-xs text-gray-500 uppercase">Ubicación</p>
                  <p className="text-white font-medium">{project.location || "Honduras"}</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg border border-white/5">
                <div className="text-gold"><Calendar size={20} /></div>
                <div>
                  <p className="text-xs text-gray-500 uppercase">Año</p>
                  <p className="text-white font-medium">{project.year || "Reciente"}</p>
                </div>
              </div>
            </div>

            <button 
              onClick={onClose}
              className="mt-8 flex items-center justify-center gap-2 w-full py-3 bg-white/5 hover:bg-gold hover:text-black text-white rounded transition-colors font-medium border border-white/10 hover:border-gold"
            >
              Cerrar Detalles <ArrowRight size={16} />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ProjectModal;