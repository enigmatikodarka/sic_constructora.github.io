import React from 'react';
import Section from './ui/Section';
import { MapPin, Warehouse } from 'lucide-react';
import { CONTACT_INFO, GOOGLE_MAPS_EMBED_URL } from '../constants';

const Location: React.FC = () => {
  return (
    <Section id="location" title="Ubicación" className="bg-dark-surface">
      <div className="flex flex-col lg:flex-row gap-10">
        
        <div className="lg:w-1/3 space-y-6">
          <h3 className="text-2xl font-bold text-white mb-6">Dónde encontrarnos</h3>
          
          <div className="bg-black p-6 rounded-lg border border-white/10 hover:border-gold/50 transition-colors">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-gold/10 rounded-full text-gold shrink-0">
                <MapPin size={24} />
              </div>
              <div>
                <h4 className="text-gold font-bold mb-2">Dirección Principal</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{CONTACT_INFO.address}</p>
              </div>
            </div>
          </div>

          <div className="bg-black p-6 rounded-lg border border-white/10 hover:border-gold/50 transition-colors">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-gold/10 rounded-full text-gold shrink-0">
                <Warehouse size={24} />
              </div>
              <div>
                <h4 className="text-gold font-bold mb-2">Plantel</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{CONTACT_INFO.plantel}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:w-2/3 h-[400px] bg-gray-900 rounded-xl overflow-hidden border border-white/10 shadow-lg">
          <iframe 
            src={GOOGLE_MAPS_EMBED_URL}
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: 'grayscale(100%) invert(92%) contrast(83%)' }} 
            allowFullScreen={true} 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Mapa de Ubicación"
          ></iframe>
        </div>

      </div>
    </Section>
  );
};

export default Location;