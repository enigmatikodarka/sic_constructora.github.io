import React, { useState } from 'react';
import Section from './ui/Section';
import { TESTIMONIALS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote, ChevronLeft, ChevronRight } from 'lucide-react';

const Testimonials: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  return (
    <Section 
        id="testimonials" 
        title="Lo Que Dicen Nuestros Clientes" 
        className="bg-dark-surface"
        pattern="grid"
    >
      <div className="max-w-4xl mx-auto relative px-12">
        <div className="absolute top-0 left-0 opacity-10">
             <Quote size={120} className="text-gold" />
        </div>

        <div className="relative overflow-hidden min-h-[300px] flex items-center justify-center">
            <AnimatePresence mode="wait">
                <motion.div 
                    key={currentIndex}
                    initial={{ opacity: 0, x: 50 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -50 }}
                    transition={{ duration: 0.5 }}
                    className="text-center z-10"
                >
                    <p className="text-xl md:text-2xl text-white font-light italic mb-8 leading-relaxed">
                        "{TESTIMONIALS[currentIndex].quote}"
                    </p>
                    <div className="flex flex-col items-center">
                        <div className="w-16 h-16 bg-gradient-to-br from-gold to-yellow-600 rounded-full flex items-center justify-center text-black font-bold text-2xl mb-4 shadow-lg">
                            {TESTIMONIALS[currentIndex].name.charAt(0)}
                        </div>
                        <h4 className="text-lg font-bold text-gold">{TESTIMONIALS[currentIndex].name}</h4>
                        <p className="text-sm text-gray-400">{TESTIMONIALS[currentIndex].role}</p>
                        <p className="text-xs text-gray-500 uppercase tracking-widest mt-1">{TESTIMONIALS[currentIndex].company}</p>
                    </div>
                </motion.div>
            </AnimatePresence>
        </div>

        {/* Navigation Buttons */}
        <button 
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 p-2 bg-black/50 border border-white/10 rounded-full text-white hover:bg-gold hover:text-black transition-all"
            aria-label="Anterior"
        >
            <ChevronLeft size={24} />
        </button>
        <button 
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 p-2 bg-black/50 border border-white/10 rounded-full text-white hover:bg-gold hover:text-black transition-all"
            aria-label="Siguiente"
        >
            <ChevronRight size={24} />
        </button>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
            {TESTIMONIALS.map((_, idx) => (
                <button
                    key={idx}
                    onClick={() => setCurrentIndex(idx)}
                    className={`w-3 h-3 rounded-full transition-all ${idx === currentIndex ? 'bg-gold w-8' : 'bg-gray-600 hover:bg-gray-400'}`}
                />
            ))}
        </div>
      </div>
    </Section>
  );
};

export default Testimonials;