import React, { useState, useEffect } from 'react';
import { Menu, X, HardHat } from 'lucide-react';
import { NAV_ITEMS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed top-0 w-full z-50 transition-all duration-300 border-b ${
        scrolled 
          ? 'bg-dark-surface/95 backdrop-blur-md border-gold/30 shadow-lg shadow-gold/5 py-3' 
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="container mx-auto px-6 flex justify-between items-center">
        
        {/* Logo Area */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="relative">
            <div className="absolute inset-0 bg-gold/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="border-2 border-gold p-2 rounded-lg relative bg-dark-surface">
                <HardHat className="text-gold w-8 h-8" />
            </div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl md:text-2xl font-display font-bold leading-none tracking-wide text-white">
              GALEL <span className="text-gold">HERNANDEZ</span>
            </h1>
            <span className="text-[10px] md:text-xs text-gold/80 uppercase tracking-widest mt-1">
              Ingeniería y Construcción
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            {NAV_ITEMS.map((item) => (
              <li key={item.label}>
                <a 
                  href={item.href} 
                  className="text-sm font-medium uppercase tracking-wider text-gray-300 hover:text-gold transition-colors relative group py-2"
                >
                  {item.label}
                  <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
            ))}
          </ul>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white hover:text-gold transition-colors"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          {menuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-dark-surface border-b border-gold/20 overflow-hidden"
          >
            <nav className="flex flex-col py-6">
              {NAV_ITEMS.map((item) => (
                <a 
                  key={item.label}
                  href={item.href} 
                  className="px-6 py-4 text-center text-white hover:bg-gold/10 hover:text-gold transition-colors font-medium border-l-4 border-transparent hover:border-gold"
                  onClick={() => setMenuOpen(false)}
                >
                  {item.label}
                </a>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;