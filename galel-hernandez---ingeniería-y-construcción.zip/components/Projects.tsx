import React, { useState } from 'react';
import Section from './ui/Section';
import { PROJECTS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, Plus } from 'lucide-react';
import { Project } from '../types';
import ProjectModal from './ui/ProjectModal';

const Projects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('Todos');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  
  // Extract unique categories
  const categories = ['Todos', ...Array.from(new Set(PROJECTS.map(p => p.category)))];

  const filteredProjects = activeCategory === 'Todos' 
    ? PROJECTS 
    : PROJECTS.filter(p => p.category === activeCategory);

  return (
    <>
      <Section 
        id="projects" 
        title="Proyectos Destacados" 
        subtitle="Una muestra de nuestra experiencia y calidad en ejecución"
        pattern="grid"
        className="bg-dark-surface"
      >
        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 rounded-full border text-sm font-medium transition-all duration-300 ${
                activeCategory === cat 
                  ? 'bg-gold border-gold text-black shadow-[0_0_10px_rgba(212,175,55,0.4)]' 
                  : 'bg-transparent border-white/20 text-gray-400 hover:border-gold/50 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <motion.div 
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence>
            {filteredProjects.map((project) => (
              <motion.div 
                layout
                key={project.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.3 }}
                onClick={() => setSelectedProject(project)}
                className="group relative overflow-hidden rounded-xl bg-black border border-white/10 h-[400px] cursor-pointer"
              >
                {/* Image */}
                <div className="absolute inset-0">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 group-hover:blur-[2px]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-90"></div>
                  
                  {/* Center Plus Icon on Hover */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-16 h-16 rounded-full bg-gold/90 text-black flex items-center justify-center transform scale-0 group-hover:scale-100 transition-transform duration-300">
                      <Plus size={32} />
                    </div>
                  </div>
                </div>

                {/* Content (Positioned at bottom) */}
                <div className="absolute bottom-0 left-0 w-full p-6 transform transition-transform duration-300 translate-y-2 group-hover:translate-y-0">
                  <span className="text-gold text-xs font-bold tracking-widest uppercase mb-2 block">
                    {project.category}
                  </span>
                  <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
                  <div className="h-0 overflow-hidden group-hover:h-auto transition-all duration-300">
                    <p className="text-gray-300 text-sm mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-100 line-clamp-2">
                      {project.description}
                    </p>
                    <span className="text-gold text-sm font-semibold flex items-center gap-2 hover:underline">
                      Ver Detalles <ExternalLink size={14} />
                    </span>
                  </div>
                </div>
                
                {/* Overlay glow on hover */}
                <div className="absolute inset-0 border-2 border-transparent group-hover:border-gold/50 rounded-xl transition-colors pointer-events-none"></div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </Section>

      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </>
  );
};

export default Projects;