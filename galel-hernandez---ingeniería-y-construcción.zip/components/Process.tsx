import React from 'react';
import Section from './ui/Section';
import { PROCESS_STEPS } from '../constants';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const Process: React.FC = () => {
  return (
    <Section 
      id="process" 
      title="Nuestro Proceso" 
      subtitle="Un flujo de trabajo optimizado para garantizar resultados excepcionales"
      className="bg-dark-surface"
    >
      <div className="mt-12 relative">
        {/* Connecting Line (Desktop) */}
        <div className="hidden lg:block absolute top-12 left-0 w-full h-0.5 bg-gradient-to-r from-transparent via-gold/30 to-transparent"></div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PROCESS_STEPS.map((step, index) => (
            <motion.div 
              key={step.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.5 }}
              className="relative group"
            >
              <div className="bg-black border border-white/5 rounded-xl p-8 hover:border-gold/50 transition-all duration-300 h-full flex flex-col items-center text-center relative z-10">
                {/* Step Number Badge */}
                <div className="absolute -top-4 bg-dark-surface border border-gold text-gold font-bold w-8 h-8 rounded-full flex items-center justify-center text-sm shadow-lg">
                  {step.id}
                </div>

                {/* Icon */}
                <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center text-gold mb-6 group-hover:scale-110 transition-transform duration-300">
                  <step.icon size={32} />
                </div>

                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{step.description}</p>
              </div>

              {/* Arrow for mobile/tablet flow */}
              {index < PROCESS_STEPS.length - 1 && (
                <div className="lg:hidden flex justify-center py-4 text-gold/30">
                  <ArrowRight size={24} className="rotate-90 md:rotate-0" />
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </Section>
  );
};

export default Process;