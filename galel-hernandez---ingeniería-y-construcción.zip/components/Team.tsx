import React from 'react';
import Section from './ui/Section';
import { TEAM } from '../constants';
import { motion } from 'framer-motion';
import { Linkedin } from 'lucide-react';

const Team: React.FC = () => {
  return (
    <Section 
      id="team" 
      title="Nuestro Equipo" 
      subtitle="Profesionales apasionados detrás de cada proyecto exitoso"
      className="bg-black"
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {TEAM.map((member, index) => (
          <motion.div 
            key={member.id}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="group relative overflow-hidden rounded-xl bg-dark-surface border border-white/5"
          >
            {/* Image Container */}
            <div className="aspect-[3/4] overflow-hidden relative">
              <img 
                src={member.image} 
                alt={member.name} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 filter grayscale group-hover:grayscale-0"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
              
              {/* Social Overlay */}
              <div className="absolute bottom-0 left-0 w-full p-6 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                <a href={member.linkedin} className="inline-flex items-center justify-center w-10 h-10 bg-gold text-black rounded-full hover:bg-white transition-colors">
                  <Linkedin size={20} />
                </a>
              </div>
            </div>

            {/* Info */}
            <div className="absolute bottom-4 left-4 right-4 bg-dark-surface/90 backdrop-blur-md p-4 rounded-lg border border-white/10 transform transition-transform duration-300 group-hover:-translate-y-2">
              <h3 className="text-lg font-bold text-white">{member.name}</h3>
              <p className="text-gold text-xs font-semibold uppercase tracking-wider">{member.role}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </Section>
  );
};

export default Team;