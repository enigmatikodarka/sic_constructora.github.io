import React, { useState } from 'react';
import Section from './ui/Section';
import { CONTACT_INFO } from '../constants';
import { Phone, Mail, Clock, Send, CheckCircle, AlertCircle } from 'lucide-react';

const Contact: React.FC = () => {
  const [formStatus, setFormStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('idle');
    // Simulate API call
    setTimeout(() => {
      setFormStatus('success');
      // Reset after a while
      setTimeout(() => setFormStatus('idle'), 5000);
    }, 1000);
  };

  return (
    <Section id="contact" title="Contáctenos" className="bg-black" pattern="dots">
      <div className="flex flex-col lg:flex-row gap-12 max-w-6xl mx-auto">
        
        {/* Contact Info Grid */}
        <div className="lg:w-5/12">
          <div className="grid grid-cols-1 gap-6">
             <div className="flex items-center gap-4 p-4 border-b border-white/10">
                <div className="text-gold"><Phone size={24} /></div>
                <div>
                   <h4 className="text-white font-semibold">Teléfonos</h4>
                   {CONTACT_INFO.phones.map(phone => (
                     <p key={phone} className="text-gray-400 text-sm">{phone}</p>
                   ))}
                </div>
             </div>

             <div className="flex items-center gap-4 p-4 border-b border-white/10">
                <div className="text-gold"><Mail size={24} /></div>
                <div>
                   <h4 className="text-white font-semibold">Email</h4>
                   {CONTACT_INFO.emails.map(email => (
                     <p key={email} className="text-gray-400 text-sm break-all">{email}</p>
                   ))}
                </div>
             </div>

             <div className="flex items-center gap-4 p-4 border-b border-white/10">
                <div className="text-gold"><Clock size={24} /></div>
                <div>
                   <h4 className="text-white font-semibold">Horario</h4>
                   <p className="text-gray-400 text-sm">Lunes - Viernes: 8:00 AM - 6:00 PM</p>
                </div>
             </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:w-7/12">
          <div className="bg-dark-surface p-8 rounded-xl border border-white/10 shadow-2xl">
            <h3 className="text-2xl font-bold text-white mb-6">Envíenos un Mensaje</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Nombre Completo</label>
                  <input 
                    type="text" 
                    required
                    className="w-full bg-black border border-white/10 rounded p-3 text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm text-gray-400">Correo Electrónico</label>
                  <input 
                    type="email" 
                    required
                    className="w-full bg-black border border-white/10 rounded p-3 text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold transition-colors"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-400">Asunto</label>
                <input 
                  type="text" 
                  required
                  className="w-full bg-black border border-white/10 rounded p-3 text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold transition-colors"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm text-gray-400">Mensaje</label>
                <textarea 
                  required
                  rows={4}
                  className="w-full bg-black border border-white/10 rounded p-3 text-white focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold transition-colors resize-none"
                ></textarea>
              </div>

              <button 
                type="submit" 
                className="w-full bg-gold hover:bg-gold-dark text-black font-bold py-4 rounded transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"
              >
                <Send size={18} />
                Enviar Mensaje
              </button>

              {formStatus === 'success' && (
                <div className="p-4 bg-green-900/30 border border-green-500/50 rounded flex items-center gap-2 text-green-400">
                  <CheckCircle size={20} />
                  <span>Mensaje enviado correctamente. Nos pondremos en contacto pronto.</span>
                </div>
              )}
               {formStatus === 'error' && (
                <div className="p-4 bg-red-900/30 border border-red-500/50 rounded flex items-center gap-2 text-red-400">
                  <AlertCircle size={20} />
                  <span>Hubo un error al enviar el mensaje. Intente nuevamente.</span>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default Contact;