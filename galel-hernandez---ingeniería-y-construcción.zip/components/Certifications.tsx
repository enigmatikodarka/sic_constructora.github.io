import React from 'react';
import { CERTIFICATIONS } from '../constants';

const Certifications: React.FC = () => {
  return (
    <div className="bg-dark-surface border-y border-white/5 py-10">
      <div className="container mx-auto px-6">
        <div className="flex flex-wrap justify-center md:justify-between items-center gap-8 md:gap-4 opacity-70 hover:opacity-100 transition-opacity duration-500">
          {CERTIFICATIONS.map((cert) => (
            <div key={cert.id} className="flex items-center gap-3 group">
              <div className="text-gray-500 group-hover:text-gold transition-colors">
                <cert.icon size={40} strokeWidth={1.5} />
              </div>
              <span className="text-sm font-semibold text-gray-400 group-hover:text-white uppercase tracking-wider transition-colors max-w-[100px]">
                {cert.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Certifications;