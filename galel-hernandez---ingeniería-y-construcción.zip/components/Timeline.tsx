import React from 'react';
import Section from './ui/Section';
import { TIMELINE } from '../constants';
import { motion } from 'framer-motion';

const Timeline: React.FC = () => {
  return (
    <Section 
        id="history" 
        title="Nuestra Trayectoria" 
        subtitle="El camino que hemos recorrido para construir excelencia"
        className="bg-black"
    >
      <div className="relative max-w-4xl mx-auto mt-12">
        {/* Vertical Line */}
        <div className="absolute left-[20px] md:left-1/2 top-0 bottom-0 w-0.5 bg-gray-800 md:transform md:-translate-x-1/2"></div>

        {TIMELINE.map((event, index) => {
          const isEven = index % 2 === 0;
          return (
            <motion.div 
              key={index}
              initial={{ opacity: 0, x: isEven ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className={`relative mb-12 flex flex-col md:flex-row ${isEven ? 'md:flex-row-reverse' : ''} items-center w-full`}
            >
              {/* Content Box */}
              <div className="w-full md:w-1/2 pl-12 md:pl-0 md:px-10 mb-4 md:mb-0">
                <div className={`bg-dark-surface p-6 rounded-xl border border-white/10 hover:border-gold/50 transition-colors relative ${isEven ? 'text-left md:text-right' : 'text-left'}`}>
                  <span className="text-gold text-2xl font-bold font-display block mb-2">{event.year}</span>
                  <h4 className="text-xl font-bold text-white mb-2">{event.title}</h4>
                  <p className="text-gray-400 text-sm leading-relaxed">{event.description}</p>
                  
                  {/* Arrow for desktop */}
                  <div className={`hidden md:block absolute top-1/2 -mt-2 w-4 h-4 bg-dark-surface border-t border-r border-white/10 transform rotate-45 ${isEven ? '-right-2.5 border-l-0 border-b-0' : '-left-2.5 border-t-0 border-r-0 border-b border-l'}`}></div>
                </div>
              </div>

              {/* Center Dot */}
              <div className="absolute left-[20px] md:left-1/2 w-4 h-4 bg-gold rounded-full border-4 border-black transform -translate-x-1/2 z-10 shadow-[0_0_10px_rgba(212,175,55,0.8)]"></div>
              
              {/* Spacer for the other side */}
              <div className="hidden md:block w-1/2"></div>
            </motion.div>
          );
        })}
      </div>
    </Section>
  );
};

export default Timeline;