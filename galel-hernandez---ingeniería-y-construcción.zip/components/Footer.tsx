import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, ArrowUp } from 'lucide-react';
import { NAV_ITEMS } from '../constants';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-dark-surface border-t border-white/5 pt-16 pb-8">
      <div className="container mx-auto px-6">
        
        {/* Socials & Nav */}
        <div className="flex flex-col items-center mb-12">
          <div className="flex gap-6 mb-8">
            {[Facebook, Twitter, Linkedin, Instagram].map((Icon, idx) => (
               <a key={idx} href="#" className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-gray-400 hover:text-black hover:bg-gold hover:border-gold transition-all duration-300">
                 <Icon size={18} />
               </a>
            ))}
          </div>

          <nav className="flex flex-wrap justify-center gap-x-8 gap-y-4 mb-8">
            {NAV_ITEMS.map((item) => (
              <a 
                key={item.label}
                href={item.href} 
                className="text-gray-400 hover:text-gold text-sm transition-colors"
              >
                {item.label}
              </a>
            ))}
          </nav>
        </div>

        {/* Divider */}
        <div className="h-px w-full bg-white/5 mb-8"></div>

        {/* Copyright */}
        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 gap-4">
          <div className="text-center md:text-left">
            <p className="mb-1">&copy; 2025 Servicios de Ingeniería y Construcción Galel Hernandez Romero SDRL.</p>
            <p>Todos los derechos reservados.</p>
          </div>
          <div className="flex items-center gap-6">
            <p>Developed by: @Chelson.tk</p>
            <button 
              onClick={scrollToTop}
              className="w-10 h-10 bg-gold/10 text-gold rounded-full flex items-center justify-center hover:bg-gold hover:text-black transition-all"
              aria-label="Volver arriba"
            >
              <ArrowUp size={18} />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;