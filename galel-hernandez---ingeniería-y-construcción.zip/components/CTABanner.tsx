import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const CTABanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show after scrolling down 300px
      if (window.scrollY > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (isDismissed) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-0 left-0 right-0 bg-dark-surface border-t-2 border-gold shadow-[0_-5px_20px_rgba(0,0,0,0.5)] z-40 p-4 md:p-6"
        >
          <div className="container mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left pr-8">
              <h4 className="text-white font-bold text-lg">¿Tiene un proyecto en mente?</h4>
              <p className="text-gray-400 text-sm">Contáctenos hoy mismo para recibir una cotización personalizada sin compromiso.</p>
            </div>
            <div className="flex items-center gap-4">
              <a 
                href="#contact" 
                className="bg-gold hover:bg-gold-dark text-black font-bold py-2 px-6 rounded transition-colors whitespace-nowrap"
              >
                Solicitar Cotización
              </a>
              <button 
                onClick={() => setIsDismissed(true)}
                className="text-gray-500 hover:text-white transition-colors absolute top-2 right-2 md:relative md:top-auto md:right-auto"
                aria-label="Cerrar"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CTABanner;