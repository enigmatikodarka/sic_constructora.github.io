import React, { useState } from 'react';
import Section from './ui/Section';
import { FAQS } from '../constants';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <Section id="faq" title="Preguntas Frecuentes" className="bg-black">
      <div className="max-w-3xl mx-auto">
        {FAQS.map((faq, index) => (
          <div key={index} className="mb-4">
            <button
              onClick={() => toggleFAQ(index)}
              className={`w-full flex items-center justify-between p-6 bg-dark-surface border ${openIndex === index ? 'border-gold' : 'border-white/10'} rounded-lg transition-colors hover:border-gold/50 text-left`}
            >
              <span className="text-lg font-medium text-white">{faq.question}</span>
              <span className={`text-gold transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`}>
                 {openIndex === index ? <Minus size={20} /> : <Plus size={20} />}
              </span>
            </button>
            <AnimatePresence>
              {openIndex === index && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="p-6 text-gray-400 border-l-2 border-gold/30 ml-4 mt-2">
                    {faq.answer}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default FAQ;