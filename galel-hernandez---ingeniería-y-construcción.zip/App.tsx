import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Stats from './components/Stats';
import Services from './components/Services';
import Timeline from './components/Timeline';
import Projects from './components/Projects';
import Testimonials from './components/Testimonials';
import Clients from './components/Clients';
import FAQ from './components/FAQ';
import Location from './components/Location';
import Contact from './components/Contact';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import Preloader from './components/ui/Preloader';
import ScrollProgress from './components/ui/ScrollProgress';
import CTABanner from './components/CTABanner';
import Process from './components/Process';
import Machinery from './components/Machinery';
import Certifications from './components/Certifications';
import CookieConsent from './components/ui/CookieConsent';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-gold selection:text-black">
      <Preloader />
      <ScrollProgress />
      <Header />
      <main>
        <Hero />
        <Stats />
        <About />
        <Certifications />
        <Process />
        <Timeline />
        <Machinery />
        <Services />
        <Projects />
        <Testimonials />
        <Clients />
        <FAQ />
        <Location />
        <Contact />
      </main>
      <Footer />
      <WhatsAppButton />
      <CTABanner />
      <CookieConsent />
    </div>
  );
};

export default App;