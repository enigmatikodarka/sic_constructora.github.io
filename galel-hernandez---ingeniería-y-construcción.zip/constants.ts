import { 
  HardHat, 
  PencilRuler, 
  Briefcase, 
  Wrench, 
  Leaf, 
  Truck,
  ClipboardList,
  DraftingCompass,
  Hammer,
  Key,
  ShieldCheck,
  Award,
  CheckCircle2,
  Tractor,
  Construction
} from 'lucide-react';
import { NavItem, Service, Project, Client, ContactInfo, Stat, TimelineEvent, Testimonial, FAQItem, ProcessStep, Certification, MachineryItem, TeamMember } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Inicio', href: '#home' },
  { label: 'Nosotros', href: '#about' },
  { label: 'Proceso', href: '#process' },
  { label: 'Servicios', href: '#services' },
  { label: 'Maquinaria', href: '#machinery' },
  { label: 'Proyectos', href: '#projects' },
  { label: 'Clientes', href: '#clients' },
  { label: 'Contacto', href: '#contact' },
];

export const SERVICES: Service[] = [
  {
    id: 1,
    title: 'Construcción Civil',
    description: 'Desarrollamos proyectos residenciales, comerciales e industriales con los más altos estándares de calidad y seguridad.',
    icon: HardHat
  },
  {
    id: 2,
    title: 'Diseño Arquitectónico',
    description: 'Creamos diseños innovadores y funcionales que se adaptan a las necesidades específicas de cada cliente.',
    icon: PencilRuler
  },
  {
    id: 3,
    title: 'Consultoría en Ingeniería',
    description: 'Ofrecemos asesoramiento especializado en todas las etapas de sus proyectos de construcción e ingeniería.',
    icon: Briefcase
  },
  {
    id: 4,
    title: 'Mantenimiento',
    description: 'Proporcionamos servicios de mantenimiento preventivo y correctivo para garantizar la durabilidad de sus instalaciones.',
    icon: Wrench
  },
  {
    id: 5,
    title: 'Construcción Sostenible',
    description: 'Implementamos prácticas y tecnologías sostenibles que minimizan el impacto ambiental de los proyectos.',
    icon: Leaf
  },
  {
    id: 6,
    title: 'Obras Públicas',
    description: 'Ejecutamos proyectos de infraestructura pública como carreteras, puentes y sistemas de saneamiento.',
    icon: Truck
  }
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: 'Caja Puente Yarula',
    category: 'Infraestructura',
    description: 'Construcción de un puente vehicular de concreto armado para mejorar la conectividad rural y garantizar el paso seguro sobre el río.',
    image: 'https://images.unsplash.com/photo-1545558014-8692077e9b5c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    client: 'Municipalidad de La Paz',
    location: 'Yarula, La Paz',
    year: '2023',
    details: 'Este proyecto consistió en la ingeniería estructural e hidráulica completa para soportar cargas pesadas y flujos de agua extremos durante la temporada de lluvias. Se utilizaron 500m³ de concreto de alta resistencia.'
  },
  {
    id: 2,
    title: 'Caja Puente Gracias',
    category: 'Infraestructura',
    description: 'Construcción de puente vehicular de concreto reforzado para fortalecer la infraestructura vial rural en Lempira.',
    image: 'https://images.unsplash.com/photo-1513828583688-6ed43003d7db?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    client: 'Fondo Vial',
    location: 'Gracias, Lempira',
    year: '2024',
    details: 'Obra civil que conecta tres comunidades productoras de café. El diseño incluyó muros de contención laterales y señalización vial nocturna.'
  },
  {
    id: 3,
    title: 'Tanques Palmerola',
    category: 'Industrial',
    description: 'Construcción e instalación de tanques de combustible en el Aeropuerto Internacional de Palmerola.',
    image: 'https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    client: 'Palmerola International Airport',
    location: 'Comayagua',
    year: '2022',
    details: 'Instalación de sistema de almacenamiento de combustible Jet A-1 bajo normativas internacionales de seguridad aeroportuaria y contención de derrames. Un hito en la infraestructura aeroportuaria del país.'
  },
  {
    id: 4,
    title: 'Edificio Corporativo Norte',
    category: 'Comercial',
    description: 'Diseño y construcción de edificio de oficinas de 5 niveles con estacionamiento subterráneo.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    client: 'Inversiones del Valle',
    location: 'San Pedro Sula',
    year: '2021',
    details: 'Edificio inteligente con certificación LEED Silver. Incluye sistemas de automatización, vidrios de control solar y estructura sismo-resistente.'
  },
  {
    id: 5,
    title: 'Carretera RN-21',
    category: 'Infraestructura',
    description: 'Pavimentación y señalización de 15km de red vial secundaria.',
    image: 'https://images.unsplash.com/photo-1584463673573-195679dc3596?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    client: 'Invest-H',
    location: 'Yoro',
    year: '2023',
    details: 'Reconstrucción de base y sub-base, aplicación de carpeta asfáltica de 7cm y obras de drenaje menor a lo largo de 15 kilómetros.'
  }
];

export const CLIENTS: Client[] = [
  { id: 1, name: 'Municipalidad de El Progreso' },
  { id: 2, name: 'Hondupalma' },
  { id: 3, name: 'Colegio de Peritos' },
  { id: 4, name: 'Ficohsa' },
  { id: 5, name: 'IPM' },
  { id: 6, name: 'IICA' },
  { id: 7, name: 'Palmerola International Airport' },
  { id: 8, name: 'Gobierno de Honduras' },
];

export const CONTACT_INFO: ContactInfo = {
  address: 'Col. Alameda, Bloque J, Cuarta calle 2 y 3 Avenida , Casa Numero 5, El Progreso, Yoro',
  plantel: 'Col. Alameda 200 mts al Sur de Texaco Guadalupana, Salida a Santa Rita, El Progreso, Yoro',
  phones: ['(504) 9557-0384', '(504) 2554-5943'],
  emails: ['galelhernandez@gmail.com', 'galelhr33@yahoo.com']
};

export const GOOGLE_MAPS_EMBED_URL = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d492401.92712364905!2d-88.10505540003281!3d15.382439553800292!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f66154d6291987f%3A0x9d34f1a048eaab7d!2sCasa%20Galel%20Hernandez%20Romero!5e0!3m2!1ses!2shn!4v1744684554710!5m2!1ses!2shn";

export const STATS: Stat[] = [
  { id: 1, value: 19, suffix: '+', label: 'Años de Experiencia' },
  { id: 2, value: 150, suffix: '+', label: 'Proyectos Ejecutados' },
  { id: 3, value: 45, suffix: '', label: 'Unidades de Maquinaria' },
  { id: 4, value: 100, suffix: '%', label: 'Clientes Satisfechos' },
];

export const TIMELINE: TimelineEvent[] = [
  { year: '2006', title: 'Fundación', description: 'Inicia operaciones Servicios de Ingeniería y Construcción Galel Hernandez, estableciendo las bases de una empresa comprometida con la calidad.' },
  { year: '2012', title: 'Consolidación de Flota', description: 'Adquisición significativa de maquinaria pesada propia, permitiendo la autonomía en proyectos viales y terracería masiva.' },
  { year: '2018', title: 'Certificación y Estándares', description: 'Implementación rigurosa de normas de seguridad industrial y gestión de calidad, abriendo puertas a clientes multinacionales.' },
  { year: '2022', title: 'Hitos en Infraestructura', description: 'Ejecución exitosa de los Tanques de Combustible en el Aeropuerto Internacional de Palmerola, consolidando nuestra capacidad en obras críticas.' },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    name: 'Ing. Roberto Martínez',
    role: 'Director de Infraestructura',
    company: 'Palmerola Int. Airport',
    quote: 'La calidad técnica y el cumplimiento de los plazos por parte de Galel Hernandez ha sido excepcional en el proyecto de tanques.'
  },
  {
    id: 2,
    name: 'Lic. María Elena Cruz',
    role: 'Gerente General',
    company: 'Inversiones del Norte',
    quote: 'Su capacidad para resolver problemas complejos de ingeniería en el sitio nos ahorró tiempo y recursos valiosos.'
  },
  {
    id: 3,
    name: 'Arq. Carlos Velásquez',
    role: 'Jefe de Proyectos',
    company: 'Municipalidad El Progreso',
    quote: 'Un aliado estratégico fundamental para el desarrollo de la infraestructura vial de nuestra ciudad.'
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "¿Realizan proyectos fuera de El Progreso?",
    answer: "Sí, tenemos capacidad logística y operativa para ejecutar proyectos en todo el territorio nacional de Honduras."
  },
  {
    question: "¿Ofrecen servicios de diseño y construcción llave en mano?",
    answer: "Absolutamente. Podemos encargarnos desde la conceptualización y planos hasta la entrega final de la obra."
  },
  {
    question: "¿Cuentan con maquinaria propia?",
    answer: "Sí, contamos con un amplio plantel de maquinaria pesada y equipo ligero propio, lo que garantiza eficiencia y mejores costos."
  },
  {
    question: "¿Cómo garantizan la calidad de los materiales?",
    answer: "Trabajamos únicamente con proveedores certificados y realizamos pruebas de laboratorio rigurosas a todos los materiales estructurales."
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    id: 1,
    title: "Planificación",
    description: "Análisis técnico de viabilidad, estudios preliminares y presupuestación detallada.",
    icon: ClipboardList
  },
  {
    id: 2,
    title: "Diseño",
    description: "Elaboración de planos arquitectónicos y estructurales optimizados para eficiencia y seguridad.",
    icon: DraftingCompass
  },
  {
    id: 3,
    title: "Construcción",
    description: "Ejecución de obra con supervisión constante, respetando cronogramas y normas de calidad.",
    icon: Hammer
  },
  {
    id: 4,
    title: "Entrega",
    description: "Revisión final, pruebas de calidad y entrega llave en mano al cliente.",
    icon: Key
  }
];

export const MACHINERY: MachineryItem[] = [
  {
    id: 1,
    name: "Excavadoras Hidráulicas",
    description: "Para movimiento de tierras masivo y excavaciones profundas.",
    count: "5+",
    icon: Tractor
  },
  {
    id: 2,
    name: "Volquetas",
    description: "Flota de camiones de 15m³ para transporte de materiales.",
    count: "10+",
    icon: Truck
  },
  {
    id: 3,
    name: "Motoniveladoras",
    description: "Equipos de precisión para nivelación y perfilado de carreteras.",
    count: "3",
    icon: Construction
  },
  {
    id: 4,
    name: "Compactadoras",
    description: "Rodillos vibratorios para compactación de suelos y asfalto.",
    count: "4",
    icon: HardHat
  }
];

export const CERTIFICATIONS: Certification[] = [
  { id: 1, name: "ISO 9001:2015", icon: Award },
  { id: 2, name: "Seguridad Industrial", icon: ShieldCheck },
  { id: 3, name: "Construcción Sostenible", icon: Leaf },
  { id: 4, name: "Control de Calidad", icon: CheckCircle2 },
];

export const TEAM: TeamMember[] = [
  {
    id: 1,
    name: "Ing. Galel Hernández",
    role: "Gerente General",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    linkedin: "#"
  },
  {
    id: 2,
    name: "Ing. Roberto Carlos",
    role: "Director de Proyectos",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    linkedin: "#"
  },
  {
    id: 3,
    name: "Arq. María Rodríguez",
    role: "Jefa de Diseño",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    linkedin: "#"
  },
  {
    id: 4,
    name: "Lic. Ana García",
    role: "Gerente Administrativa",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    linkedin: "#"
  }
];